# Task 1 - MERN Stack (Tutedude)

## Description
This task displays "Hello World!" using a basic HTML file.

## How to Run
Open index.html in any web browser.

## Output
Hello World! is displayed on the screen.